"""
Agent flows for Odoo 18 MCP Integration.
"""
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Streamlit Client Package

This package provides a Streamlit client for the Odoo 18 MCP project.
"""

from .main import main

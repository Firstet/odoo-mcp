"""Odoo 18 MCP Integration project.

This package provides integration between Odoo 18 and MCP.
"""

__version__ = "0.1.0"
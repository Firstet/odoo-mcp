#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from setuptools import setup

# This file is here for backward compatibility with older pip versions
# Modern Python packaging uses pyproject.toml
setup()